package iwwwdnw.exception;

@SuppressWarnings("serial")
public class PlatzierException extends Exception {
	public PlatzierException(String msg) {
		super(msg);
	}
}
