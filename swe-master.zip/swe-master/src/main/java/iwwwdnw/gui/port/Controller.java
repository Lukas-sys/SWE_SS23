package iwwwdnw.gui.port;

import iwwwdnw.statemachine.port.Observer;

public interface Controller extends Observer {

    void doit();

}