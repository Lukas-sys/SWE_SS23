package iwwwdnw.ui.port;

public interface UiPort {

	public Ui ui();
}
