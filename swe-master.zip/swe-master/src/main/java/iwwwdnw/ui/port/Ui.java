package iwwwdnw.ui.port;

public interface Ui {
	void startEventLoop();
}
