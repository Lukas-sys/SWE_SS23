package iwwwdnw.ui.impl.view;

public class ViewFactory {

}
