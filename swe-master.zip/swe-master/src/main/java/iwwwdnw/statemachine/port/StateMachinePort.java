package iwwwdnw.statemachine.port;

public interface StateMachinePort {

    public StateMachine stateMachine();

}
