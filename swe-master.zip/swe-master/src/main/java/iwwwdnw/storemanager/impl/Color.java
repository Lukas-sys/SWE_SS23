package iwwwdnw.storemanager.impl;

public enum Color {
    RED,YELLOW, GREEN, BLUE, BLACK, PURPLE
}
