package iwwwdnw.storemanager.port;

public interface StoreManagerPort {

    StoreManagement storeManagement();

}
