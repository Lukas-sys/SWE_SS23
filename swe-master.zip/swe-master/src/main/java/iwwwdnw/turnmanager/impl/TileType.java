package iwwwdnw.turnmanager.impl;

public enum TileType {
    OUTER, INNER, CONNECTOR
}
