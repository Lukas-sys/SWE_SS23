package iwwwdnw.turnmanager.port;

public interface TurnManagerPort {

    TurnManagement turnManagement();

}
