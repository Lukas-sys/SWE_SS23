package iwwwdnw.spielzugmanager.port;

public interface Wuerfel {

	void werfeWuerfel();
	int getWuerfel1();
	int getWuerfel2();
	int getInsAugenzahl();
	
}
