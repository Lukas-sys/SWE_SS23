package iwwwdnw.spielzugmanager.port;

public interface SpielzugManagerPort {

	SpielzugManager spielzugManager();
}
