package iwwwdnw.Logic.port;

import iwwwdnw.statemachine.port.Subject;

public interface SubjectPort {
    public Subject subject();
}
