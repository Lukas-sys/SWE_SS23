package iwwwdnw.Logic.port;

import iwwwdnw.storemanager.port.StoreManagerPort;
import iwwwdnw.turnmanager.port.TurnManagerPort;

public interface ManagerPort extends TurnManagerPort, StoreManagerPort {
	
}
