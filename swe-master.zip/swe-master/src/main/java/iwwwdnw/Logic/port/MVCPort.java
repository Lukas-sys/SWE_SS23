package iwwwdnw.Logic.port;

public interface MVCPort extends SubjectPort {
}
