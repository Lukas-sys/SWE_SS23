package iwwwdnw.DatabaseConnector.port;
public interface Store {
}
