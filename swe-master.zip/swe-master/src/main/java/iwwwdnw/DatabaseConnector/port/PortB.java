
package iwwwdnw.DatabaseConnector.port;

public interface PortB {


	void i2();

}
