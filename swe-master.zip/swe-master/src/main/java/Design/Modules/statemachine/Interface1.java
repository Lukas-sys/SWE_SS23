package Design.Modules.statemachine;
public interface Interface1 {
}
