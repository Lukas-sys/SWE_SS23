package Design.Components;
public interface I_Spiel {
}
