package Analyse.UseCase1;
public class DB {


	public void getKategorien() {
		return;
	}
}
