package Analyse.ObjectModel;

public class Herausforderer extends Spieler {
}