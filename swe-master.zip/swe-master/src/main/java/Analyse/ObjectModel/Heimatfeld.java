package Analyse.ObjectModel;

public class Heimatfeld extends Feld {
}