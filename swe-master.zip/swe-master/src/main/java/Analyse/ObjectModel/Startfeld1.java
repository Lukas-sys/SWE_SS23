package Analyse.ObjectModel;

public class Startfeld1 {
}