
package Analyse.ObjectModel;

public class Würfel {

	/**
	 * @clientCardinality 2
	 * @clientNavigability NAVIGABLE
	 * @label < nutzt 
	 * @supplierCardinality 1
	 */

	Analyse.ObjectModel.Spiel lnkSpiel = null;

}