
package Analyse.ObjectModel;

public class Datenbank {


	
	/**
	 * @clientCardinality 1
	 * @clientNavigability NAVIGABLE
	 * @label speichert >
	 * @supplierCardinality 1..*
	 */
	
	Analyse.ObjectModel.Fragekarte lnkFragekarte = null;


	public void getKategorien() {
		return;
	}

}