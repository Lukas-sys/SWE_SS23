package Analyse.ObjectModel;

public class Frage {


	/**
	 * @clientCardinality 1
	 * @label < hat 
	 * @link composition
	 * @supplierCardinality 4
	 */
	private Analyse.ObjectModel.Antwort lnkAntwort;
}