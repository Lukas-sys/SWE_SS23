package Analyse.ObjectModel;

public class Feld {


	
	/**
	 * @clientCardinality entsprechend Anzahl der Spieler
	 * @clientNavigability NAVIGABLE
	 * @label < hat
	 * @supplierCardinality 1
	 */
	
	Analyse.ObjectModel.Brett lnkBrett = null;
}