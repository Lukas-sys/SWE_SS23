package Analyse.ObjectModel;

public class Spiel {


	
	/**
	 * @clientCardinality 1
	 * @clientNavigability NAVIGABLE
	 * @label hat >
	 * @supplierCardinality 1
	 */
	
	Analyse.ObjectModel.Brett lnkBrett = null;














	public void playDuell() {
		return;
	}


	public void move() {
		return;
	}


	public void moveFigur() {
		return;
	}


	public void placeFigur() {
		return;
	}


	public void wuerfeln() {
		return;
	}


	public void initBrett() {
		return;
	}


	public void startSpiel() {
		return;
	}


	public void initWissensanzeiger() {
		return;
	}


	public void chooseKategorien() {
		return;
	}


	public void showKategorien() {
		return;
	}


	public void reihenfolgeFestlegen() {
		return;
	}


	public void getWuerfeln() {
		return;
	}


	public void registration() {
		return;
	}
}