package Analyse.ObjectModel;

/**
 * @metaclass associationClass
 */

public class würfeln {
}
