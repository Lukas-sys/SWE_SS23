package Analyse.ObjectModel;

public class Duellsieger extends Spieler {
}