package Analyse.ObjectModel;

public class Duellverlierer extends Spieler {
}