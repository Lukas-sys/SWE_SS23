package Analyse.ObjectModel;

public class Brett {
}