
package Analyse.ObjectModel;

public class Antwort {

}