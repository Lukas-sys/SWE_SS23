package Analyse.ObjectModel;

public class Wissensstandsanzeiger {


	/**
	 * @clientCardinality 4
	 * @clientNavigability NAVIGABLE
	 * @label besitzt >
	 * @link association
	 * @supplierCardinality 1
	 */
	Analyse.ObjectModel.Spieler lnkSpieler = null;
}