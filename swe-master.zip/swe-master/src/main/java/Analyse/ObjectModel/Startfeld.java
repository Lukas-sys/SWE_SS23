package Analyse.ObjectModel;

public class Startfeld extends Feld {
}