package Analyse.ObjectModel;

public class Herausfordernder extends Spieler {
}