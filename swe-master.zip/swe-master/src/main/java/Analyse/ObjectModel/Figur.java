package Analyse.ObjectModel;

public class Figur {


	
	/**
	 * @clientCardinality 0..2
	 * @clientNavigability NAVIGABLE
	 * @supplierCardinality 1
	 */
	
	Analyse.ObjectModel.Feld lnkFeld = null;
}