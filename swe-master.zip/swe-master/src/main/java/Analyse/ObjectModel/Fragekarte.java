
package Analyse.ObjectModel;

public class Fragekarte {

	/**
	 * @clientCardinality 1
	 * @label ^hat
	 * @link composition
	 * @supplierCardinality 3
	 */
	private Analyse.ObjectModel.Frage lnkFrage;

}